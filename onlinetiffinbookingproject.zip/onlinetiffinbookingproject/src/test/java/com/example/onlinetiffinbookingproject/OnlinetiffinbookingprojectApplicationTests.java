package com.example.onlinetiffinbookingproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinetiffinbookingprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
