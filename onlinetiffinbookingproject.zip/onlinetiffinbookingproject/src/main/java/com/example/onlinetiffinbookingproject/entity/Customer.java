package com.example.onlinetiffinbookingproject.entity;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.lang.NonNull;


@Entity
@Table(name="customer")
public class Customer {
	
	@Id
	@GeneratedValue (strategy = GenerationType.AUTO)
	private int customerId;
	
	@NonNull
	private String customerName;
	
	private String customerPhoneNo;
	
	private String customerAddress;
	
	private String menuitemCatogery;
	
	private String menuitemName;
	
	private String menuitemQuantity;
	
	private double amount;

	public Customer() {
		// TODO Auto-generated constructor stub
	}
	
	

	public Customer(int customerId, String customerName, String customerPhoneNo, String customerAddress,
			String menuitemCatogery, String menuitemName, String menuitemQuantity, double amount) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerPhoneNo = customerPhoneNo;
		this.customerAddress = customerAddress;
		this.menuitemCatogery = menuitemCatogery;
		this.menuitemName = menuitemName;
		this.menuitemQuantity = menuitemQuantity;
		this.amount = amount;
	}



	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhoneNo() {
		return customerPhoneNo;
	}

	public void setCustomerPhoneNo(String customerPhoneNo) {
		this.customerPhoneNo = customerPhoneNo;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getMenuitemCatogery() {
		return menuitemCatogery;
	}

	public void setMenuitemCatogery(String menuitemCatogery) {
		this.menuitemCatogery = menuitemCatogery;
	}

	public String getMenuitemName() {
		return menuitemName;
	}

	public void setMenuitemName(String menuitemName) {
		this.menuitemName = menuitemName;
	}

	public String getMenuitemQuantity() {
		return menuitemQuantity;
	}

	public void setMenuitemQuantity(String menuitemQuantity) {
		this.menuitemQuantity = menuitemQuantity;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}



	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerPhoneNo="
				+ customerPhoneNo + ", customerAddress=" + customerAddress + ", menuitemCatogery=" + menuitemCatogery
				+ ", menuitemName=" + menuitemName + ", menuitemQuantity=" + menuitemQuantity + ", amount=" + amount
				+ "]";
	}


	


}
