package com.example.onlinetiffinbookingproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinetiffinbookingprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinetiffinbookingprojectApplication.class, args);
	}

}
